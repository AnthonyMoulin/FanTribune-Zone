# 🎟️ FanTribune – NFT & Fan Token Stadium Experience

**FanTribune** est une application mobile Web3 qui permet aux fans de football d’acheter des **places virtuelles en tribune** sous forme de **NFT**, de représenter leur équipe avec un **fan token (FTZ)**, et de participer à une économie d’engagement immersive et communautaire.

## 🚀 Vision
Recréer l’émotion des anciens tickets de match grâce à une application moderne, décentralisée et ludique.

## 📲 Fonctionnalités principales
- 🏟️ Billetterie virtuelle NFT
- 💰 Token FTZ pour achat, vote, récompenses
- 📈 Valeur des places liée à l’affluence
- 🎴 NFT collectors (Section 144, Homme du match)
- 👥 DAO Fan Club

## 📦 Contenu
Voir dossiers : `pitch-deck/`, `tokenomics/`, `assets/`

## 💼 Auteur
**Anthony Moulin** – antmoulin1@gmail.com – Le Puy-en-Velay

## ⚠️ Disclaimer
Ce projet est en phase de prototypage. Aucune levée de fonds ni vente de token n’est actuellement en cours.